# 🎴 FitGirl Modern Gaming Library (Chrome Web Store Edition)

A powerful, high-performance Chrome Extension that transforms **[fitgirl-repacks.site](https://fitgirl-repacks.site)** into a state-of-the-art modern games library with Steam ratings, high-density data tables, auto-rotating hero spotlight, magnet downloads, glassmorphic side filter drawer, and infinite scroll.

---

## 🌟 Key Features

- **🛍️ Chrome Web Store Ready**: 100% compliant with Chrome Web Store Developer policies (Manifest V3, privacy-first, zero third-party telemetry).
- **🎴 Cards & ☰ Table View**: Toggle between a visual poster card grid and a high-density tabular view with Steam ratings, size ranges, and release dates.
- **🔥 Auto-Rotating Top Hero Spotlight**: Interactive hero banner featuring top spotlight repacks and FitGirl's upcoming compression queue.
- **⚙️ Side Filter Drawer**: Glassmorphic filter panel with instant filtering by Steam rating, repack size range, genre, and sort orders.
- **⌨️ Keyboard Shortcuts**: Press `Ctrl + K` (or `Cmd + K`) anywhere on the page to focus the search bar instantly.
- **❤️ Standout Donation Cards**: Dedicated glowing cards for FitGirl site support & seedbox donations.

---

## 🚀 How to Publish to Chrome Web Store

### 1. Zip the Extension Package
Create a zip file containing the project directory or run:
```powershell
Compress-Archive -Path background.js, content.js, styles.css, manifest.json, popup.html, popup.js, icons -DestinationPath fitgirl-modern-library-extension.zip -Force
```

### 2. Upload to Chrome Developer Dashboard
1. Go to the **[Chrome Developer Console](https://chrome.google.com/webstore/devconsole)**.
2. Click **New Item** and upload `fitgirl-modern-library-extension.zip`.
3. Fill out the Store Listing:
   - **Title**: `FitGirl Modern Gaming Library`
   - **Category**: `Fun / Games`
   - **Privacy Policy / Permissions Rationale**: "Transforms website DOM to provide a modernized gaming library view."
4. Click **Publish Item**.

---

## 🔄 How Version Updates Work on Chrome Web Store

Whenever you want to release an update to your users:
1. Increase the version number in `manifest.json`:
   ```json
   "version": "1.0.1"
   ```
2. Re-create the `.zip` file.
3. Open **Chrome Developer Console** -> Select your extension -> Click **Upload updated package**.
4. Once Google approves the update (~a few hours), Google Chrome will **automatically update the extension in the background for all your users silently**!
